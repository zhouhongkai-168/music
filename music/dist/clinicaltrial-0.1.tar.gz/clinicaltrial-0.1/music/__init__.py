from __future__ import absolute_import
from .music import *

__version__ = '1.0.0'
__license__ = ''

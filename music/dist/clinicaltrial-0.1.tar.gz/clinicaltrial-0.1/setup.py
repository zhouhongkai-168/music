from setuptools import setup
setup(name='clinicaltrial',
      version='0.1',
      description='clinical trial information retriver',
      url='http://github.com/tongling/clinicaltrial',
      author='Ling',
      author_email='tonglingacademic@gmail.com',
      license='MIT',
      packages=['music'],
      zip_safe=False)
